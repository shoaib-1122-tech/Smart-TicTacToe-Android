package com.example.myapplication;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Random;

public class TicTacToeActivity extends AppCompatActivity {

    int activePlayer = 0; // 0: X, 1: O
    int[] gameState = {2, 2, 2, 2, 2, 2, 2, 2, 2};
    int[][] winningPositions = {{0,1,2}, {3,4,5}, {6,7,8}, {0,3,6}, {1,4,7}, {2,5,8}, {0,4,8}, {2,4,6}};
    boolean gameActive = true;
    String mode;
    Button btnRestart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tic_tac_toe);

        mode = getIntent().getStringExtra("mode"); // Mode check karna
        btnRestart = findViewById(R.id.btnRestart);

        // Grid buttons setup
        for (int i = 0; i < 9; i++) {
            int resId = getResources().getIdentifier("btn" + i, "id", getPackageName());
            Button btn = findViewById(resId);
            btn.setOnClickListener(this::onCellClick);
        }

        btnRestart.setOnClickListener(v -> restartGame());
    }

    public void onCellClick(View view) {
        Button btn = (Button) view;
        int tappedTag = Integer.parseInt(btn.getResources().getResourceEntryName(btn.getId()).substring(3));

        if (gameState[tappedTag] == 2 && gameActive) {
            performMove(btn, tappedTag);

            // Smart AI Move
            if (gameActive && "ai".equals(mode) && activePlayer == 1) {
                new Handler().postDelayed(this::computerMove, 500); // 0.5 sec delay
            }
        }
    }

    private void performMove(Button btn, int tag) {
        gameState[tag] = activePlayer;
        if (activePlayer == 0) {
            btn.setText("X");
            btn.setTextColor(android.graphics.Color.CYAN);
            activePlayer = 1;
        } else {
            btn.setText("O");
            btn.setTextColor(android.graphics.Color.YELLOW);
            activePlayer = 0;
        }
        checkWinner();
    }

    // --- SMART AI LOGIC START ---
    private void computerMove() {
        if (!gameActive) return;

        int move = findWinningMove(1); // 1. Khud jeetne ki koshish

        if (move == -1) {
            move = findWinningMove(0); // 2. Player ko block karna
        }

        if (move == -1 && gameState[4] == 2) {
            move = 4; // 3. Center lena
        }

        if (move == -1) { // 4. Random move
            Random rand = new Random();
            while (true) {
                int r = rand.nextInt(9);
                if (gameState[r] == 2) { move = r; break; }
                boolean full = true;
                for(int s : gameState) if(s==2) full=false;
                if(full) break;
            }
        }

        if (move != -1) {
            int resId = getResources().getIdentifier("btn" + move, "id", getPackageName());
            Button btn = findViewById(resId);
            performMove(btn, move);
        }
    }

    private int findWinningMove(int player) {
        for (int[] winPos : winningPositions) {
            int count = 0, emptyIndex = -1;
            if (gameState[winPos[0]] == player) count++; else if (gameState[winPos[0]] == 2) emptyIndex = winPos[0];
            if (gameState[winPos[1]] == player) count++; else if (gameState[winPos[1]] == 2) emptyIndex = winPos[1];
            if (gameState[winPos[2]] == player) count++; else if (gameState[winPos[2]] == 2) emptyIndex = winPos[2];
            if (count == 2 && emptyIndex != -1) return emptyIndex;
        }
        return -1;
    }
    // --- SMART AI LOGIC END ---

    private void checkWinner() {
        for (int[] winPos : winningPositions) {
            if (gameState[winPos[0]] == gameState[winPos[1]] &&
                    gameState[winPos[1]] == gameState[winPos[2]] &&
                    gameState[winPos[0]] != 2) {

                gameActive = false;

                String winner = (gameState[winPos[0]] == 0) ? "Player X Wins!" : "Player O Wins!";
                Toast.makeText(this, winner, Toast.LENGTH_LONG).show();
                btnRestart.setVisibility(View.VISIBLE); // Play Again button dikhana
                return;
            }
        }

        boolean isDraw = true;
        for (int s : gameState) if (s == 2) isDraw = false;
        if (isDraw && gameActive) {
            gameActive = false;
            Toast.makeText(this, "It's a Draw!", Toast.LENGTH_LONG).show();
            btnRestart.setVisibility(View.VISIBLE);
        }
    }

    private void restartGame() {
        activePlayer = 0;
        gameActive = true;
        btnRestart.setVisibility(View.GONE); // Button chhupana
        for (int i = 0; i < 9; i++) {
            gameState[i] = 2;
            int resId = getResources().getIdentifier("btn" + i, "id", getPackageName());
            Button btn = findViewById(resId);
            btn.setText("");
        }
    }
}