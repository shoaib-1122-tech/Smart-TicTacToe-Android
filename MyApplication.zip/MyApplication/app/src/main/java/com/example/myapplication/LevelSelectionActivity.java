package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class LevelSelectionActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_level_selection);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });



        // 1 vs AI Button
        Button btnVsAI = findViewById(R.id.btnVsAI);
        btnVsAI.setOnClickListener(v -> {
            Intent intent = new Intent(LevelSelectionActivity.this, TicTacToeActivity.class);
            intent.putExtra("mode", "ai");
            startActivity(intent);
        });

        // 1 vs 1 (Friend) Button
        Button btnVsFriend = findViewById(R.id.btnVsFriend);
        btnVsFriend.setOnClickListener(v -> {
            Intent intent = new Intent(LevelSelectionActivity.this, TicTacToeActivity.class);
            intent.putExtra("mode", "friend");
            startActivity(intent);
        });
    }
}